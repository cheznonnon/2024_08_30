// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/neutral/posix.c"

#include "../../nonnon/neutral/filer.c"
#include "../../nonnon/neutral/string_path.c"




// internal
n_posix_bool
n_mac_tools_dotfiles_remover( const n_posix_char *folder )
{

	n_posix_bool ret = n_posix_false;


	if ( folder != NULL )
	{

		n_posix_DIR *dp = n_posix_opendir_nodot( folder );
		if ( dp == NULL ) { return n_posix_true; }


		// [!] : 1 == n_posix_strlen( N_POSIX_SLASH )

		n_type_int cch = n_posix_strlen( folder ) + 1;

		n_posix_loop
		{//break;

			n_posix_dirent *dirent = n_posix_readdir( dp );
			if ( dirent == NULL ) { break; }

			n_posix_char *item = n_string_path_new( cch + n_posix_strlen( dirent->d_name ) );
			n_string_path_make( folder, dirent->d_name, item );

			if ( n_posix_stat_is_dir( item ) )
			{
				n_mac_tools_dotfiles_remover( item );

				if ( dirent->d_name[ 0 ] == n_posix_literal( '.' ) )
				{
					n_filer_remove( item );
				}
			} else
			if ( dirent->d_name[ 0 ] == n_posix_literal( '.' ) )
			{
				n_filer_remove( item );
			}

			n_string_path_free( item );

		}


		n_posix_closedir( dp );


//n_posix_debug_literal( "%d %d", d->dir, d->file );

	}


	return ret;
}

