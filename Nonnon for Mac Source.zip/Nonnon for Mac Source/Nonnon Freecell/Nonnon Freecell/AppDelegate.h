//
//  AppDelegate.h
//  Nonnon Freecell
//
//  Created by のんのん on 2022/07/20.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

